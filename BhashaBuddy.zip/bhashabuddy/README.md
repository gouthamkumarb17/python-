# BhashaBuddy (VoiceBridge Jam)
Bilingual (English / Telugu / Hindi / Tamil) technical-English learning app. Plain HTML + CSS + JavaScript, no build step.

## Run
Speech recognition needs https or localhost:
    cd bhashabuddy && python3 -m http.server 8000   # open http://localhost:8000 in Chrome/Edge

## Structure
- index.html        page shell (header, view container, tab bar)
- css/styles.css    design tokens + notebook-page flashcard, mobile first
- js/data.js        UI strings per language (I18N) + vocabulary (RAW rows: add words here)
- js/storage.js     localStorage profile, daily goal, streak, mastered words
- js/speech.js      SpeechSynthesis (TTS), SpeechRecognition, Levenshtein scoring (distance <= 2 forgiven)
- js/app.js         views (Learn, Quiz, Progress), click handler, render loop
- sw.js             service worker for offline use

## Demo flow
Switch to తె -> open "Algorithm" -> Listen -> Speak -> "Pronunciation Match" + goal meter updates.
If SpeechRecognition is unavailable (e.g. Firefox), a typed-answer fallback is shown.
