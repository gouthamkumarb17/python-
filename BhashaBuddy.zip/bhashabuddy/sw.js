// Offline cache: app shell is cached on install, other GETs cached as they load.
const C='bb-v1',F=['./','index.html','css/styles.css','js/data.js','js/storage.js','js/speech.js','js/app.js'];
self.addEventListener('install',e=>e.waitUntil(caches.open(C).then(c=>c.addAll(F))));
self.addEventListener('fetch',e=>{if(e.request.method!=='GET')return;
  e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request).then(res=>{const cp=res.clone();caches.open(C).then(c=>c.put(e.request,cp));return res}).catch(()=>r)));});
