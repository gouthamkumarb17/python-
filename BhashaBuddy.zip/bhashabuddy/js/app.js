// ===== UI: tiny view router, flashcards, quiz, progress =====
const $=s=>document.querySelector(s);
const t=k=>(I18N[S.lang]&&I18N[S.lang][k])||I18N.en[k];
const shuffle=a=>[...a].sort(()=>Math.random()-.5);
let tab='learn',unit=1,pos=0,fb='',Q=null;
const list=()=>WORDS.filter(w=>w.u===unit);

const meter=()=>`<div class="meter"><i style="width:${Math.min(100,S.done.length/S.goal*100)}%"></i><b>${t('goal')}: ${S.done.length}/${S.goal}${S.done.length>=S.goal?' ★ '+t('done'):''}</b></div>`;

function learn(){
  const L=list(),w=L[pos%L.length];
  const mean=S.lang==='en'?['te','hi','ta'].map(k=>`<span lang="${k}">${w[k]}</span>`).join(''):`<span lang="${S.lang}">${w[S.lang]}</span>`;
  return meter()+`<div class="units">${UNITS.map((n,i)=>`<button class="chip ${i+1===unit?'on':''}" data-a="unit" data-v="${i+1}">${t('unit')} ${i+1}: ${n}</button>`).join('')}</div>
  <article class="card">
    <p class="meta">${pos%L.length+1}/${L.length}</p>
    <h2 class="word">${w.en}</h2><p class="ph">/ ${w.ph} /</p>
    <div class="mean">${mean}</div>
    <p class="ex"><b>${t('example')}:</b> ${w.ex}</p>
    <div class="row"><button class="btn" data-a="listen">🔊 ${t('listen')}</button>
    ${SR?`<button class="btn go" data-a="speak">🎤 ${t('speak')}</button>`:`<input type="text" id="typed" placeholder="${t('type')}" aria-label="${t('type')}"><button class="btn go" data-a="check">${t('check')}</button>`}</div>
    <div id="fb" role="status" aria-live="polite">${fb}</div>
  </article>
  <div class="nav"><button class="btn" data-a="prev">← ${t('prev')}</button><button class="btn" data-a="next">${t('next')} →</button></div>`;
}
function result(p,w){
  fb=`<span class="pct ${p>=80?'good':'bad'}">${t('match')}: ${p}%</span><br>${p>=80?'🎉 '+t('great'):t('retry')}`;
  if(p>=80)credit(w.id);
}
function startQuiz(){
  const ql=S.lang==='en'?'te':S.lang;                // English UI quizzes in Telugu meanings
  Q={i:0,s:0,ql,items:shuffle(WORDS).slice(0,5).map((w,k)=>({w,blank:k%2,pick:null,opts:shuffle([w,...shuffle(WORDS.filter(x=>x!==w)).slice(0,3)])}))};
}
function quiz(){
  if(!Q)return meter()+`<button class="big" data-a="start">${t('start')}</button>`;
  if(Q.i>=Q.items.length)return `<div class="stat"><span>${t('score')}</span><b>${Q.s}/${Q.items.length}</b></div>${meter()}<button class="big" data-a="start">${t('again')}</button>`;
  const it=Q.items[Q.i],w=it.w;
  const head=it.blank?`<b>${t('fill')}</b><br>${w.ex.replace(new RegExp(w.en,'i'),'_____')}<br><span lang="${Q.ql}">${w[Q.ql]}</span>`:`${t('pick')} <b>${w.en}</b>`;
  const opts=it.opts.map(o=>{const c=it.pick===null?'':o.id===w.id?'ok':o.id===it.pick?'no':'';
    return `<button class="opt ${c}" data-a="pick" data-v="${o.id}" ${it.pick!==null?'disabled':''}><span lang="${Q.ql}">${it.blank?o.en:o[Q.ql]}</span></button>`}).join('');
  const verdict=it.pick===null?'':`<p class="${it.pick===w.id?'good':'bad'}"><b>${it.pick===w.id?t('correct'):t('wrong')+' '+(it.blank?w.en:w[Q.ql])}</b></p><button class="btn go" data-a="qnext">${t('next')} →</button>`;
  return `<article class="card"><p class="meta">${Q.i+1}/${Q.items.length}</p><p>${head}</p>${opts}${verdict}</article>`;
}
function progress(){
  return meter()+`<div class="stat"><span>${t('streak')}</span><b>${S.streak}</b></div>
  <div class="stat"><span>${t('mastered')}</span><b>${S.mastered.length}/${WORDS.length}</b></div>
  <p><b>${t('target')}</b></p><div class="row">${[3,5,10].map(n=>`<button class="chip ${S.goal===n?'on':''}" data-a="goal" data-v="${n}">${n}</button>`).join('')}</div>`;
}
const VIEWS={learn,quiz,progress};
function render(){
  document.documentElement.lang=S.lang;
  $('#view').innerHTML=VIEWS[tab]();
  $('#langs').innerHTML=LANGS.map(([c,l])=>`<button class="${c===S.lang?'on':''}" data-a="lang" data-v="${c}" aria-label="${c}">${l}</button>`).join('');
  $('#tabs').innerHTML=Object.keys(VIEWS).map(k=>`<button class="${k===tab?'on':''}" data-a="tab" data-v="${k}">${t(k)}</button>`).join('');
}
document.addEventListener('click',e=>{
  const b=e.target.closest('[data-a]');if(!b)return;
  const a=b.dataset.a,v=b.dataset.v,L=list(),w=L[pos%L.length];
  if(a==='tab'){tab=v;fb=''}
  else if(a==='lang'){S.lang=v;save();Q=null}
  else if(a==='unit'){unit=+v;pos=0;fb=''}
  else if(a==='next'){pos++;fb=''}
  else if(a==='prev'){pos=(pos-1+L.length)%L.length;fb=''}
  else if(a==='listen'){say(w.en+'. '+w.ex);return}
  else if(a==='speak'){fb=t('listening');render();listen(w.en,p=>{result(p,w);render()},()=>{fb=t('nospeech');render()});return}
  else if(a==='check'){result(score($('#typed').value||'',w.en),w)}
  else if(a==='start'){startQuiz()}
  else if(a==='pick'){const it=Q.items[Q.i];if(it.pick!==null)return;it.pick=+v;if(it.pick===it.w.id){Q.s++;credit(it.w.id)}}
  else if(a==='qnext'){Q.i++}
  else if(a==='goal'){S.goal=+v;save()}
  render();
});
render();
