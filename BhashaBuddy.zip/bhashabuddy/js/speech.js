// ===== Speech: text-to-speech, speech recognition, Levenshtein scoring =====
const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
function say(text){
  if(!('speechSynthesis' in window))return;
  speechSynthesis.cancel();
  const u=new SpeechSynthesisUtterance(text);u.lang='en-IN';u.rate=.85;speechSynthesis.speak(u);
}
function lev(a,b){
  const d=Array.from({length:a.length+1},(_,i)=>[i,...Array(b.length).fill(0)]);
  for(let j=1;j<=b.length;j++)d[0][j]=j;
  for(let i=1;i<=a.length;i++)for(let j=1;j<=b.length;j++)
    d[i][j]=Math.min(d[i-1][j]+1,d[i][j-1]+1,d[i-1][j-1]+(a[i-1]===b[j-1]?0:1));
  return d[a.length][b.length];
}
function score(heard,target){                       // 0-100; distance <= 2 is forgiven for accents
  const a=heard.toLowerCase().trim(),b=target.toLowerCase(),d=lev(a,b);
  let p=Math.max(0,Math.round((1-d/Math.max(a.length,b.length,1))*100));
  if(d<=2&&b.length>3)p=Math.max(p,80);
  return p;
}
function listen(target,onScore,onFail){
  const r=new SR();r.lang='en-IN';r.maxAlternatives=5;
  r.onresult=e=>onScore(Math.max(...[...e.results[0]].map(x=>score(x.transcript,target))));
  r.onerror=onFail;r.onnomatch=onFail;
  try{r.start()}catch(e){onFail()}
}
